from __future__ import print_function
from sympy import *
from sympy.interactive.printing import init_printing
init_printing(use_unicode=False, wrap_line=False)



def RegularisedInvariants2D():
    """2D regularrised invariants of distortion energies expressed
        in terms of standard invariants
    """

    s1, s2, b, I_F, II_F, I_H, II_H, J = symbols("s1 s2 b I_F II_F I_H II_H J")

    print("2D regularised invariants")

    # First regularised invariant - I_Fr
    I_Fr = (s1 + b) + (s2 + b)
    I_Fr = I_Fr.subs(s1 + s2, I_F)
    print("1st regularised invariant I_Fr =", I_Fr)

    # Second regularised invariant - II_Fr
    II_Fr = (s1 + b)**2 + (s2 + b)**2
    II_Fr = expand(II_Fr)
    II_Fr = collect(II_Fr, b)
    II_Fr = II_Fr.subs(2*s1 + 2*s2, 2*I_F)
    II_Fr = II_Fr.subs(s1**2 + s2**2, II_F)
    print("2nd regularised invariant II_Fr =", II_Fr)

    # Third regularised invariant - I_Hr
    I_Hr = (s2 + b) + (s1 + b)
    I_Hr = expand(I_Hr)
    I_Hr = collect(I_Hr, b)
    I_Hr = I_Hr.subs(s1 + s2, I_F)
    print("3rd regularised invariant I_Hr =", I_Hr)

    # Fourth regularised invariant - I_Hr
    II_Hr = (s2 + b)**2 + (s1 + b)**2
    II_Hr = expand(II_Hr)
    II_Hr = collect(II_Hr, b)
    II_Hr = II_Hr.subs(2*s1 + 2*s2, 2*I_F)
    II_Hr = II_Hr.subs(s1**2 + s2**2, II_F)
    print("4th regularised invariant II_Hr =", II_Hr)

    # First regularised invariant - Jr
    Jr = (s1 + b) * (s2 + b)
    Jr = expand(Jr)
    Jr = collect(Jr, b)
    Jr = Jr.subs(s1 + s2, I_F)
    Jr = Jr.subs(s1 * s2, J)
    print("Fifth regularised invariant Jr =", Jr)

    print()



def RegularisedInvariants3D():
    """3D regularrised invariants of distortion energies expressed
        in terms of standard invariants
    """

    s1, s2, s3, b, I_F, II_F, I_H, II_H, J = symbols("s1 s2 s3 b I_F II_F I_H II_H J")

    print("3D regularised invariants")

    # First regularised invariant - I_Fr
    I_Fr = (s1 + b) + (s2 + b) + (s3 + b)
    I_Fr = I_Fr.subs(s1 + s2 + s3, I_F)
    print("1st regularised invariant I_Fr =", I_Fr)

    # Second regularised invariant - II_Fr
    II_Fr = (s1 + b)**2 + (s2 + b)**2 + (s3 + b)**2
    II_Fr = expand(II_Fr)
    II_Fr = collect(II_Fr, b)
    II_Fr = II_Fr.subs(2*s1 + 2*s2 + 2*s3, 2*I_F)
    II_Fr = II_Fr.subs(s1**2 + s2**2 + s3**2, II_F)
    print("2nd regularised invariant II_Fr =", II_Fr)

    # Third regularised invariant - I_Hr
    I_Hr = (s1 + b) * (s2 + b) + (s1 + b) * (s3 + b) + (s2 + b) * (s3 + b)
    I_Hr = expand(I_Hr)
    I_Hr = collect(I_Hr, b)
    I_Hr = I_Hr.subs(2*s1 + 2*s2 + 2*s3, 2*I_F)
    I_Hr = I_Hr.subs(s1*s2 + s1*s3 + s2*s3, I_H)
    print("3rd regularised invariant I_Hr =", I_Hr)

    # Fourth regularised invariant - I_Hr
    II_Hr = (s1 + b)**2 * (s2 + b)**2 + (s1 + b)**2 * (s3 + b)**2 + (s2 + b)**2 * (s3 + b)**2
    II_Hr = expand(II_Hr)
    II_Hr = collect(II_Hr, b)
    II_Hr = II_Hr.subs(4*s1 + 4*s2 + 4*s3, 4*I_F)
    II_Hr = II_Hr.subs(2*s1**2 + 2*s2**2 + 2*s3**2, 2*II_F)
    II_Hr = II_Hr.subs(4*s1*s2 + 4*s1*s3 + 4*s2*s3, 4*I_H)
    II_Hr = II_Hr.subs(s1**2*s2**2 + s1**2*s3**2 + s2**2*s3**2, II_H)
    # That last term involving III_F
    last = II_Hr.coeff(b,1)
    print("4th regularised invariant II_Hr =", II_Hr)

    # First regularised invariant - Jr
    Jr = (s1 + b) * (s2 + b) * (s3 + b)
    Jr = expand(Jr)
    Jr = collect(Jr, b)
    Jr = Jr.subs(s1 + s2 + s3, I_F)
    Jr = Jr.subs(s1*s2 + s1*s3 + s2*s3, I_H)
    Jr = Jr.subs(s1 * s2 * s3, J)
    print("Fifth regularised invariant Jr =", Jr)

    print()


RegularisedInvariants2D()

RegularisedInvariants3D()

