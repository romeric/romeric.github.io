from __future__ import print_function
# from symengine import *
# import sympy as sp
from sympy import *
from sympy.interactive.printing import init_printing
init_printing(use_unicode=False, wrap_line=False)

def AnalyticEigensystem(Psi):

    I1, I2, I3 = symbols("I1 I2 I3")
    sigma0, sigma1, sigma2, sigmai, sigmaj, sigmak = symbols("s1 s2 s3 sigmai sigmaj sigmak")
    J, s, Jr = symbols("J s Jr")

    lambdas = zeros(9,1);

    # x-twist, y-twist, and z-twist
    lambdas[3] = (2 / (sigma1 + sigma2)) * diff(Psi, I1) +\
                2 * diff(Psi, I2) + sigma0 * diff(Psi, I3);
    lambdas[4] = (2 / (sigma0 + sigma2)) * diff(Psi, I1) +\
                2 * diff(Psi, I2) + sigma1 * diff(Psi, I3);
    lambdas[5] = (2 / (sigma0 + sigma1)) * diff(Psi, I1) +\
                2 * diff(Psi, I2) + sigma2 * diff(Psi, I3);

    # x-flip, y-flip, and z-flip
    lambdas[6] = 2 * diff(Psi, I2) - sigma0 * diff(Psi, I3);
    lambdas[7] = 2 * diff(Psi, I2) - sigma1 * diff(Psi, I3);
    lambdas[8] = 2 * diff(Psi, I2) - sigma2 * diff(Psi, I3);

    # x-scale
    lambdas[0] = 2 * diff(Psi, I2) +\
               diff(Psi, I1, 2) +\
               4 * sigma0**2 * diff(Psi, I2, 2) +\
               sigma1**2 * sigma2**2 * diff(Psi, I3, 2) +\
               4 * sigma0 * diff(diff(Psi, I1), I2) +\
               4 * I3 * diff(diff(Psi, I2), I3) +\
               2 * sigma1 * sigma2 * diff(diff(Psi, I3), I1)

    # y-scale
    lambdas[1] = 2 * diff(Psi, I2) +\
               diff(Psi, I1, 2) +\
               4 * sigma1**2 * diff(Psi, I2, 2) +\
               sigma0**2 * sigma2**2 * diff(Psi, I3, 2) +\
               4 * sigma1 * diff(diff(Psi, I1), I2) +\
               4 * I3 * diff(diff(Psi, I2), I3) +\
               2 * sigma0 * sigma2 * diff(diff(Psi, I3), I1)

    # z-scale
    lambdas[2] = 2 * diff(Psi, I2) +\
               diff(Psi, I1, 2) +\
               4 * sigma2**2 * diff(Psi, I2, 2) +\
               sigma0**2 * sigma1**2 * diff(Psi, I3, 2) +\
               4 * sigma2 * diff(diff(Psi, I1), I2) +\
               4 * I3 * diff(diff(Psi, I2), I3) +\
               2 * sigma0 * sigma1 * diff(diff(Psi, I3), I1)
    # ------------------------------------------------------------------#

    # ------------------------------------------------------------------#
    A = zeros(3,3)

    # first derivatives
    firstI1 = diff(Psi, I1)
    firstI2 = diff(Psi, I2)
    firstI3 = diff(Psi, I3)

    # second derivatives
    secondI1 = diff(firstI1, I1)
    secondI2 = diff(firstI2, I2)
    secondI3 = diff(firstI3, I3)

    # mixed derivatives
    secondI1I2 = diff(firstI1, I2)
    secondI1I3 = diff(firstI1, I3)
    secondI2I3 = diff(firstI2, I3)

    # get the diagonal entry
    aii = 2 * firstI2 + secondI1 + 4 * sigmai**2 * secondI2 +\
        (I3 / sigmai)**2 * secondI3 + 4 * sigmai * secondI1I2 +\
        4 * I3 * secondI2I3 + 2 * (I3 / sigmai) * secondI1I3
    A[0,0] = aii.subs(sigmai, sigma0)
    A[1,1] = aii.subs(sigmai, sigma1)
    A[2,2] = aii.subs(sigmai, sigma2)

    # get the off-diagonal entry
    aij = sigmak * firstI3 + secondI1 + 4 * (I3 / sigmak) * secondI2 +\
        sigmak * I3 * secondI3 +\
        2 * sigmak * (I2 - sigmak**2) * secondI2I3 +\
        (I1 - sigmak) * (sigmak * secondI1I3 + 2 * secondI1I2)
    A[0,1] = aij.subs(sigmak, sigma2)
    A[0,2] = aij.subs(sigmak, sigma1)
    A[1,2] = aij.subs(sigmak, sigma0)

    # % symmetrize and simplify
    A[1,0] = A[0,1]
    A[2,0] = A[0,2]
    A[2,1] = A[1,2]

    A = A.subs(I1, sigma0+sigma1+sigma2)
    A = A.subs(I2, sigma0**2 + sigma1**2 + sigma2**2)
    A = A.subs(I3, sigma0*sigma1*sigma2)
    A = simplify(A)

    if True:
        print("Scaling modes do not decouple")
        A = A.subs(I3, J)
        # A = A.subs(sqrt(J**2 + d2), s)
        A = A.subs(sigma0*sigma1*sigma2, J)
        # A = simplify(A) # turn on for simplified forms

        print("const Real a11 = ", cxxcode(A[0,0], standard="C++17"),";")
        print("const Real a12 = ", cxxcode(A[0,1], standard="C++17"),";")
        print("const Real a13 = ", cxxcode(A[0,2], standard="C++17"),";")
        print("const Real a22 = ", cxxcode(A[1,1], standard="C++17"),";")
        print("const Real a23 = ", cxxcode(A[1,2], standard="C++17"),";")
        print("const Real a33 = ", cxxcode(A[2,2], standard="C++17"),";")

        # eigenvalues = A.eigenvals().items()
    # ------------------------------------------------------------------#

    # get compact expressions for the eigenvalues
    for i in range(9):
        lambdas[i] = lambdas[i].subs(I3, J)
        lambdas[i] = lambdas[i].subs(I1, sigma0+sigma1+sigma2)
        lambdas[i] = lambdas[i].subs(I2, sigma0**2 + sigma1**2 + sigma2**2)
        lambdas[i] = lambdas[i].subs(J, sigma0*sigma1*sigma2)
        # lambdas[i] = simplify(lambdas[i]) # turn on for simplified forms

        xx = cxxcode(lambdas[i], standard="C++17")
        print("Real lambda"+str(i+1)+" = ", xx,";")

I1, I2, I3, d2, Jr, beta, lamb, dr = symbols("I1 I2 I3 delta2 Jr beta lamb dr")
I_F = I1
II_F = I2
J = I3
I_H = Rational(1, 2) * (I_F**2 - II_F)
II_H = I_H**2 - 2 * I_F * J
III_F = I_F**3 - 3*(I_F*I_H - J)

# When beta is a variable; d2 is constant here
# Jr = Rational(1, 2) * (I3 + sqrt(I3**2 + d2))
# When beta is constant
II_Fr = II_F + 2 * beta * I_F + 3 * beta**2
II_Hr = II_H + 2 * beta * (I_F*II_F - III_F) + 2 * beta**2 * I_F**2 + 4 * beta**3 * I_F + 3 * beta**4
Jr = J + I_H * beta + I_F * beta**2 + beta**3

# Energies:

# RMIPS
Psi = 1/Jr**Rational(2, 3) * (II_F * Rational(1,3) + beta * I_F * Rational(1,3) + beta**2)
# RSD
Psi = Rational(1,2) * (II_Fr + II_Hr / Jr**2)

AnalyticEigensystem(Psi)

