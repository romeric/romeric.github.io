from __future__ import print_function
from sympy import *
from sympy.interactive.printing import init_printing
init_printing(use_unicode=False, wrap_line=False)


def InvariantProperties():
    """Properties of invariants
    """

    s1, s2, s3 = symbols("s1 s2 s3")

    I_F = s1 + s2 + s3
    II_F = s1**2 + s2**2 + s3**2
    I_H = s1*s2 + s1*s3 + s2*s3
    II_H = (s1*s2)**2 + (s1*s3)**2 + (s2*s3)**2
    J = s1*s2*s3

    # Verify that I_H = 1/2 * (I_F**2 - II_F)
    I_H_calc = expand((I_F**2 - II_F) / 2)
    print(I_H_calc == I_H)

    # Verify that II_H = I_H**2 - 2 * I_F * J
    II_H_calc = simplify(expand(I_H**2 - 2* I_F * J))
    print(II_H_calc == II_H)

    # Verify that I_F**2 - 3*I_H = II_F - I_H
    # Can be verified from I_H = 1/2 * (I_F**2 - II_F)
    prop1 = simplify(expand(II_F - I_H))
    prop1_calc = simplify(expand(I_F**2 - 3*I_H))
    print(prop1_calc == prop1)


InvariantProperties()

