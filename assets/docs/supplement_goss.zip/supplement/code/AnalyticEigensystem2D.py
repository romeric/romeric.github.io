from __future__ import print_function
from sympy import *
from sympy.interactive.printing import init_printing
init_printing(use_unicode=False, wrap_line=False)

def AnalyticEigensystem(Psi):

    I1, I2, I3 = symbols("I1 I2 I3")
    sigma0, sigma1 = symbols("s1 s2")
    J, J2, s, Jr, Jr2, dJrdJ, d2JrdJ2 = symbols("J J2 s Jr Jr2 D D2")

    lambdas = zeros(4,1);

    # If the eigenpairs decouple these are the eigenvalues
    # ------------------------------------------------------------------#
    # twist
    lambdas[3] = (2 / I1) * diff(Psi, I1) +\
                2 * diff(Psi, I2) +\
                diff(Psi, I3);
    # flip
    lambdas[2] = 2 * diff(Psi, I2) - diff(Psi, I3);

    # x-scale
    lambdas[0] =\
               2 * diff(Psi, I2) +\
               diff(Psi, I1, 2) +\
               4 * sigma0**2 * diff(Psi, I2, 2) +\
               sigma1**2 * diff(Psi, I3, 2) +\
               4 * sigma0 * diff(diff(Psi, I1), I2) +\
               4 * I3 * diff(diff(Psi, I2), I3) +\
               2 * sigma1 * diff(diff(Psi, I3), I1);

    # y-scale
    lambdas[1] = 2 * diff(Psi, I2) +\
               diff(Psi, I1, 2) +\
               4 * sigma1**2 * diff(Psi, I2, 2) +\
               sigma0**2 * diff(Psi, I3, 2) +\
               4 * sigma1 * diff(diff(Psi, I1), I2) +\
               4 * I3 * diff(diff(Psi, I2), I3) +\
               2 * sigma0 * diff(diff(Psi, I3), I1);
    # ------------------------------------------------------------------#

    # If the do not decouple, we need to build matrix A
    # ------------------------------------------------------------------#
    a11 = 2 * diff(Psi, I2) +\
         diff(Psi, I1, 2) +\
         4 * sigma0**2 * diff(Psi, I2, 2) +\
         sigma1**2 * diff(Psi, I3, 2) +\
         4 * sigma0 * diff(diff(Psi, I1), I2) +\
         4 * I3 * diff(diff(Psi, I2), I3) +\
         2 * sigma1 * diff(diff(Psi, I3), I1);

    a22 = 2 * diff(Psi, I2) +\
         diff(Psi, I1, 2) +\
         4 * sigma1**2 * diff(Psi, I2, 2) +\
         sigma0**2 * diff(Psi, I3, 2) +\
         4 * sigma1 * diff(diff(Psi, I1), I2) +\
         4 * I3 * diff(diff(Psi, I2), I3) +\
         2 * sigma0 * diff(diff(Psi, I3), I1);

    # off-diagonals
    a12 = \
         diff(Psi, I3) +\
         diff(Psi, I1, 2) +\
         4 * I3 * diff(Psi, I2, 2) +\
         I3 * diff(Psi, I3, 2) +\
         2 * I1 * diff(diff(Psi, I1), I2) +\
         2 * I2 * diff(diff(Psi, I2), I3) +\
         I1 * diff(diff(Psi, I3), I1);
    a21 = a12

    # Check if they do decouple
    if a12 != 0:
      print("Scaling modes do not decouple")
      A = Matrix([[a11, a12], [a21, a22]])
      A = A.subs(sqrt(I3**2 + d2), s)
      A = A.subs(I3, J)
      A = A.subs(I1*beta + J + beta**2, Jr)
      A = simplify(A)

      print("const Real a11 = ", cxxcode(A[0,0], standard="C++17"),";")
      print("const Real a12 = ", cxxcode(A[0,1], standard="C++17"),";")
      print("const Real a22 = ", cxxcode(A[1,1], standard="C++17"),";")
      print()
      eigenvalues = A.eigenvals().items()

      lambdas[0] = eigenvalues[0][0]
      lambdas[1] = eigenvalues[1][0]

    # ------------------------------------------------------------------#

    # get compact expressions for the eigenvalues
    for i in range(4):
        lambdas[i] = lambdas[i].subs(I3, J)
        lambdas[i] = lambdas[i].subs(sqrt(J**2 + d2), s)
        lambdas[i] = lambdas[i].subs(I1*beta + J + beta**2, Jr)
        lambdas[i] = lambdas[i].subs(sigma0*sigma1, J)
        lambdas[i] = simplify(lambdas[i])

        xx = cxxcode(lambdas[i], standard="C++17")
        print("Real lambda" + str(i+1) + " = ", xx, ";")


# ------------------------------------------------------------------#
I1, I2, I3, d2, Jr, beta, mu, lamb, dr = symbols("I1 I2 I3 delta2 Jr beta m_mu m_lambda dr")
# When beta is a variable; d2 is constant here
# Jr = Rational(1, 2) * (I3 + sqrt(I3**2 + d2))
# When beta is constant
Jr = I3 + I1 * beta + beta**2
IIFr = I2 + 2* (I1 * beta + beta**2)


# Energies:

# RMIPS
# Psi = I2/Jr/2 - I3 / Jr 
# RAMIPS
# Psi = I2/Jr/2 - I3 / Jr + lamb * (Jr + Jr**(-1) ) 
# RSD
Psi = I2/2 * (1 + 1/Jr/Jr) + (Jr + 1 / Jr - I3 - I3/Jr/Jr) 
# RSARAP
# Psi = I2/2 * (1 + 1/Jr/Jr) - I1 * (1 + 1/Jr) + (Jr + 1 / Jr - I3 - I3/Jr/Jr) - 2 * beta * (1 + 1/Jr)  
AnalyticEigensystem(Psi)
# ------------------------------------------------------------------#
