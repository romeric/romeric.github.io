Supplemental material for the Transaction on Graphics paper:
Geometric Optmisation Via Spectral Shifting

The following items are included:
1. Detailed derivations and per element C++ inline code in SupplementalDocument_GOSS.pdf
2. Python scripts to generate energy Hessian eigensystems
3. Simulation videos